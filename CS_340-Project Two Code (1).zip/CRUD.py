from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections.
        # This is hard-wired to use the aac database, the 
        # animals collection, and the aac user.
        # Definitions of the connection string variables are
        # unique to the individual Apporto environment.
        #
        # You must edit the connection variables below to reflect
        # your own instance of MongoDB!
        #
        # Connection Variables
        #
        USER = 'aacuser'
        PASS = 'poojasingh'
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 32182
        DB = 'AAC'
        COL = 'animals'
        #
        # Initialize Connection
        #
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]
        
# Method to implement the C in CRUD.  
    def create(self, data):
        if data is not None:
            insert = self.database.animals.insert(data)  # data should be dictionary
            if insert != 0:
                return True
            else:
                return False
        else:
            raise Exception("Nothing to save, because data parameter is empty")

# Method to implement the R in CRUD.
    def read(self, criteria=None):
        if criteria is not None:
            data = self.database.animals.find(criteria,{"_id": False})
            for document in data:
                print(document)
            
        else:
            data = self.database.animals.find({},{"_id": False})
        
        return data
    
# Create method to implement the U in CRUD.
    def update(self, query, new_values):
        """Update documents in the collection"""
        try:
            result = self.collection.update_many(query, {"$set": new_values})
            print("Update successful")
            return result.modified_count
            
        except Exception as e:
            print(f"Error updating documents: {e}")
            return 0

# Create method to implement the D in CRUD.
    def delete(self, query):
        """Delete documents from the collection"""
        try:
            result = self.collection.delete_many(query)
            print("Deletion successful")
            return result.deleted_count
        except Exception as e:
            print(f"Error deleting documents: {e}")     
            return 0